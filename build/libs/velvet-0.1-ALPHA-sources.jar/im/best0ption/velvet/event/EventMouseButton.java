package im.best0ption.velvet.event;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EventMouseButton {

    private int button;
    /** {@link com.mojang.blaze3d.platform.InputConstants#PRESS} or {@link com.mojang.blaze3d.platform.InputConstants#RELEASE}. */
    private int action;
    /** Scaled (GUI) coordinates. */
    private float mouseX;
    private float mouseY;
}