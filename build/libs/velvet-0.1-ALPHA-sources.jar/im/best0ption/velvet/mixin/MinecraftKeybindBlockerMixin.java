package im.best0ption.velvet.mixin;

import im.best0ption.velvet.VelvetHack;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftKeybindBlockerMixin {

    @Inject(method = "handleKeybinds", at = @At("HEAD"), cancellable = true)
    private void velvet$skipGameplayKeybindsWhileGuiOpen(CallbackInfo ci) {
        // While the GUI is up the mouse is released, but Minecraft would still
        // process attack/use/inventory clicks since screen() is null. Skip it.
        if (VelvetHack.getInstance().getClickGUIScreen().isOpened()) {
            KeyMapping.releaseAll();
            ci.cancel();
        }
    }
}