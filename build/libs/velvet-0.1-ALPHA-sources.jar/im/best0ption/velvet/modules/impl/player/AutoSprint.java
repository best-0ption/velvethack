package im.best0ption.velvet.modules.impl.player;

import com.google.common.eventbus.Subscribe;
import im.best0ption.velvet.event.EventTick;
import im.best0ption.velvet.modules.Module;
import im.best0ption.velvet.modules.ModuleRegister;
import im.best0ption.velvet.modules.Type;
import im.best0ption.velvet.settings.BooleanSetting;
import im.best0ption.velvet.settings.ModeSetting;
import im.best0ption.velvet.settings.SliderSetting;

@ModuleRegister(name = "AutoSprint", type = Type.Player)
public class AutoSprint extends Module {

    private final BooleanSetting keepSprint = new BooleanSetting("Keep Sprint", true);
    private final SliderSetting speed = new SliderSetting("Speed", 1.0f, 0.1f, 5.0f, 0.1f);
    private final ModeSetting mode = new ModeSetting("Mode", new String[]{"Always", "Legit"});

    public AutoSprint() {
        addSettings(mode, keepSprint, speed);
    }

    @Subscribe
    public void onUpdate(EventTick eventTick) {
        if (mc.player == null) return;

        boolean moving = mc.player.input.hasForwardImpulse();

        if (mode.getValue().equals("Legit")) {
            if (moving) {
                mc.options.keySprint.setDown(true);
            } else if (!keepSprint.getValue()) {
                mc.options.keySprint.setDown(false);
            }
        } else {
            mc.options.keySprint.setDown(true);
        }
    }
}