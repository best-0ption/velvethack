package im.best0ption.velvet.modules.impl.render;

import com.google.common.eventbus.Subscribe;
import im.best0ption.velvet.event.EventTick;
import im.best0ption.velvet.modules.Module;
import im.best0ption.velvet.modules.ModuleRegister;
import im.best0ption.velvet.modules.Type;
import im.best0ption.velvet.settings.BooleanSetting;
import im.best0ption.velvet.settings.SliderSetting;

@ModuleRegister(name = "FullBright", type = Type.Render)
public class FullBright extends Module {

    private final BooleanSetting smooth = new BooleanSetting("Smooth", true);
    private final SliderSetting gamma = new SliderSetting("Gamma", 5.0f, 0.5f, 5.0f, 0.1f);
    private Double originalGamma;

    public FullBright() {
        addSettings(gamma, smooth);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.options != null) {
            originalGamma = mc.options.gamma().get();
            mc.options.gamma().set((double) gamma.getValue());
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.options != null && originalGamma != null) {
            mc.options.gamma().set(originalGamma);
            originalGamma = null;
        }
    }

    @Subscribe
    public void onTick(EventTick eventTick) {
        if (mc.options != null) {
            mc.options.gamma().set((double) gamma.getValue());
        }
    }
}