package im.best0ption.velvet.render.font;

public class FontManager {
    public static boolean inited = false;
    public static MsdfFont biko;
    public static MsdfFont sfmedium;
    public static MsdfFont sfsemibold;
    public static MsdfFont consolas;
    public static MsdfFont sfbold;

    public static void init() {

        biko = new MsdfFont("biko");
        sfmedium = new MsdfFont("sfmedium");
        sfbold = new MsdfFont("sfbold");
        sfsemibold = new MsdfFont("sfsemibold");
        consolas = new MsdfFont("consolas");
        inited = true;
    }
}
