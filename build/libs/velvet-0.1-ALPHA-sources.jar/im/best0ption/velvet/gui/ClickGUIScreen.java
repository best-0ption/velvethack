package im.best0ption.velvet.gui;

import com.google.common.eventbus.Subscribe;
import im.best0ption.velvet.VelvetHack;
import im.best0ption.velvet.event.EventMouseButton;
import im.best0ption.velvet.event.EventMouseScroll;
import im.best0ption.velvet.event.EventRender2D;
import im.best0ption.velvet.event.EventTick;
import im.best0ption.velvet.modules.Module;
import im.best0ption.velvet.modules.Type;
import im.best0ption.velvet.render.RenderUtils;
import im.best0ption.velvet.render.font.FontManager;
import im.best0ption.velvet.settings.BooleanSetting;
import im.best0ption.velvet.settings.ModeSetting;
import im.best0ption.velvet.settings.Setting;
import im.best0ption.velvet.settings.SliderSetting;
import im.best0ption.velvet.util.AnimationValue;
import im.best0ption.velvet.util.Easing;
import im.best0ption.velvet.util.IMinecraft;
import im.best0ption.velvet.util.MouseUtility;
import lombok.Getter;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Getter
//FUCK YOUR MOJANG!!! IM DONT USE YOUR FUCKING SCREEN.CLASS!!!!
public class ClickGUIScreen implements IMinecraft {

    // --- layout constants (scaled by anim) ---
    private static final float SIDEBAR_WIDTH = 100f;
    private static final float MODULE_ROW_HEIGHT = 24f;
    private static final float ROW_GAP = 2f;
    private static final float SETTING_ROW_HEIGHT = 20f;
    private static final float SETTING_GAP = 2f;
    private static final float EXPAND_BUTTON_SIZE = 14f;
    private static final float TOGGLE_WIDTH = 26f;
    private static final float TOGGLE_HEIGHT = 12f;

    // --- colors ---
    private static final int BG = RenderUtils.rgb(14, 14, 14);
    private static final int SIDEBAR_BG = RenderUtils.rgb(18, 18, 18);
    private static final int SIDEBAR_BTN = RenderUtils.rgb(25, 25, 25);
    private static final int SIDEBAR_BTN_HOVER = RenderUtils.rgb(38, 38, 38);
    private static final int ROW_BG = RenderUtils.rgb(27, 27, 27);
    private static final int ROW_HOVER = RenderUtils.rgb(40, 40, 40);
    private static final int ROW_ENABLED = RenderUtils.rgb(34, 28, 48);
    private static final int SETTING_BG = RenderUtils.rgb(20, 20, 20);
    private static final int TRACK = RenderUtils.rgb(62, 62, 62);
    private static final int DIVIDER = RenderUtils.rgb(120, 120, 120);
    private static final int TEXT = RenderUtils.rgb(235, 235, 235);
    private static final int ACCENT = RenderUtils.rgb(157, 120, 255);
    private static final int ACCENT_SOFT = RenderUtils.rgb(70, 50, 112);
    private static final int WHITE = RenderUtils.rgb(255, 255, 255);

    public boolean opened;
    private boolean closing;
    private final AnimationValue anim = new AnimationValue(0.5f, Easing.CUBIC_IN_OUT);

    private Type selectedType = Type.Player;
    private int scrollOffset;
    private Module expanded;
    private SliderSetting draggingSlider;
    private long lastDebugLog;

    public ClickGUIScreen() {}

    public void open() {
        System.out.println("[VELVET-DEBUG] open() called, anim=" + anim.get());
        anim.reset();
        anim.setReverse(false);
        anim.start();
        closing = false;
        opened = true;
    }

    public void close() {
        if (!opened || closing) return;
        closing = true;
        anim.setReverse(true);
    }

    // ============================================================
    //  Events
    // ============================================================

    @Subscribe
    public void onTick(EventTick eventTick) {
    }

    @Subscribe
    public void onRender(EventRender2D eventRender2D) {
        if (!opened) return;

        mc.mouseHandler.releaseMouse();

        anim.update(mc.getDeltaTracker().getRealtimeDeltaTicks() / 20f);

        long nowMs = System.currentTimeMillis();
        if (nowMs - lastDebugLog > 1000) {
            lastDebugLog = nowMs;
            System.out.println("[VELVET-DEBUG] onRender opened= " + opened
                    + " anim=" + anim.get()
                    + " guiScaled=" + mc.getWindow().getGuiScaledWidth() + "x" + mc.getWindow().getGuiScaledHeight()
                    + " layout=" + layout());
        }

        if (anim.get() <= 0f) {
            opened = false;
            closing = false;
            if (mc.gui.screen() == null) {
                mc.mouseHandler.grabMouse();
            }
            return;
        }

        Layout l = layout();
        float mouseX = (float) mc.mouseHandler.getScaledXPos(mc.getWindow());
        float mouseY = (float) mc.mouseHandler.getScaledYPos(mc.getWindow());

        // keep dragging a slider while the mouse is held even outside the bar
        if (draggingSlider != null && mc.mouseHandler.isLeftPressed()) {
            updateSliderDrag(l, mouseX);
        }

        GuiGraphicsExtractor g = eventRender2D.getGraphics();

        // window body
        RenderUtils.drawRoundedRectangle(g, l.x(), l.y(), l.width(), 9 * l.a(), l.height(), BG);

        // sidebar
        RenderUtils.drawRoundedRectangle(g, l.x(), l.y(), SIDEBAR_WIDTH * l.a(), 9 * l.a(), l.height(), SIDEBAR_BG);
        RenderUtils.drawRoundedRectangle(g, l.x() + SIDEBAR_WIDTH * l.a(), l.y(), 1 * l.a(), 0, l.height(), DIVIDER);

        // logo + title
        RenderUtils.drawTexture(g, Identifier.fromNamespaceAndPath("velvet", "textures/icon"),
                l.x() + 6 * l.a(), l.y() + 15 * l.a(), 25 * l.a(), 20 * l.a(), 0, WHITE);
        FontManager.sfbold.drawDefaultString(g, "Velvet", l.x() + 35 * l.a(), l.y() + 17 * l.a(),
                16 * l.a(), RenderUtils.rgba(255, 255, 255, (int) (255 * l.a())));

        // category buttons
        drawCategoryButtons(g, l, mouseX, mouseY);

        // module list
        float scissorX = l.listX() - 2 * l.a();
        float scissorY = l.listTop() - 2 * l.a();
        g.enableScissor(Math.round(scissorX), Math.round(scissorY),
                Math.round(scissorX + l.listW() + 4 * l.a()), Math.round(scissorY + l.listH() + 4 * l.a()));
        renderModules(g, l, mouseX, mouseY);
        g.disableScissor();
    }

    @Subscribe
    public void onMouseButton(EventMouseButton event) {
        if (!opened) return;
        // only left button interactions
        if (event.getButton() != 0) return;

        if (event.getAction() == 0) { // RELEASE
            draggingSlider = null;
            return;
        }

        float mx = event.getMouseX();
        float my = event.getMouseY();
        Layout l = layout();

        handleSidebarClick(l, mx, my);
        handleModuleClick(l, mx, my);
    }

    @Subscribe
    public void onMouseScroll(EventMouseScroll event) {
        if (!opened) return;
        double dy = event.getScrollY();
        if (dy == 0) return;

        Layout l = layout();
        if (l.rowStep() <= 0) return;
        int visible = (int) (l.listH() / l.rowStep());
        int maxScroll = Math.max(0, selectedModules().size() - visible);
        int delta = dy > 0 ? -3 : 3;
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset + delta));
    }

    // ============================================================
    //  Layout helpers (shared by render + hit-testing)
    // ============================================================

    private record Layout(
            float x, float y, float width, float height, float a,
            float listX, float listTop, float listW, float listH, float rowStep) {

        static Layout of(float gw, float gh, float a) {
            float width = Math.min(450, gw - 20) * a;
            float height = Math.min(350, gh - 20) * a;
            float x = gw / 2f - width / 2;
            float y = gh / 2f - height / 2;
            float listX = x + 104 * a;
            float listW = Math.max(0, width - 108 * a);
            float listTop = y + 10 * a;
            float listH = Math.max(0, height - 20 * a);
            float rowStep = (MODULE_ROW_HEIGHT + ROW_GAP) * a;
            return new Layout(x, y, width, height, a, listX, listTop, listW, listH, rowStep);
        }
    }

    private Layout layout() {
        return Layout.of(mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight(), anim.get());
    }

    private List<Module> selectedModules() {
        return VelvetHack.getInstance().getModuleInitializator().getModules().stream()
                .filter(m -> m.getType() == selectedType)
                .collect(Collectors.toList());
    }

    /** Placement of every visible module row, expanded settings included. */
    private List<Slot> slots(Layout l) {
        List<Module> modules = selectedModules();
        List<Slot> result = new ArrayList<>();
        if (l.rowStep() <= 0) return result;

        float y = l.listTop();
        float rowH = MODULE_ROW_HEIGHT * l.a();
        float settingBlock = expandedSettingCount() * (SETTING_ROW_HEIGHT + SETTING_GAP) * l.a();
        for (int i = scrollOffset; i < modules.size(); i++) {
            Module module = modules.get(i);
            if (module == expanded) {
                result.add(new Slot(module, y, rowH, expandedSettingCount()));
            } else {
                result.add(new Slot(module, y, rowH, 0));
            }
            y += l.rowStep();
            if (module == expanded) {
                y += settingBlock;
            }
            if (y > l.listTop() + l.listH() + 20 * l.a()) break;
        }
        return result;
    }

    private int expandedSettingCount() {
        return expanded == null ? 0 : expanded.getSettings().size();
    }

    private record Slot(Module module, float y, float rowHeight, int settingRows) {}

    private float toggleX(Layout l, float rowX, float rowW) {
        return rowX + rowW - 4 * l.a() - TOGGLE_WIDTH * l.a();
    }

    private float toggleY(Layout l, float rowY, float rowH) {
        return rowY + (rowH - TOGGLE_HEIGHT * l.a()) / 2f;
    }

    private float expandX(Layout l, float rowX, float rowW) {
        return toggleX(l, rowX, rowW) - 4 * l.a() - EXPAND_BUTTON_SIZE * l.a();
    }

    private float expandY(Layout l, float rowY, float rowH) {
        return rowY + (rowH - EXPAND_BUTTON_SIZE * l.a()) / 2f;
    }

    // --- category buttons ---

    private float categoryButtonX(Layout l) {
        return l.x() + 6.5f;
    }

    private float categoryButtonY(Layout l, int index) {
        return l.y() + 60 * l.a() + index * 40 * l.a();
    }

    private float categoryButtonW(Layout l) {
        return 89 * l.a();
    }

    private float categoryButtonH(Layout l) {
        return 35 * l.a();
    }

    // ============================================================
    //  Rendering
    // ============================================================

    private void drawCategoryButtons(GuiGraphicsExtractor g, Layout l, float mouseX, float mouseY) {
        Type[] types = Type.values();
        for (int i = 0; i < types.length; i++) {
            float bx = categoryButtonX(l);
            float by = categoryButtonY(l, i);
            float bw = categoryButtonW(l);
            float bh = categoryButtonH(l);
            boolean selected = types[i] == selectedType;
            boolean hovered = MouseUtility.isHovered(mouseX, mouseY, bx, by, bw, bh);

            int bg = hovered ? SIDEBAR_BTN_HOVER : SIDEBAR_BTN;
            RenderUtils.drawRoundedRectangle(g, bx, by, bw, 6 * l.a(), bh, bg);
            if (selected) {
                RenderUtils.drawRoundedBorder(g, bx, by, bw, bh, 6 * l.a(), 1 * l.a(), ACCENT);
            }

            String text = types[i].name();
            float textSize = 11 * l.a();
            float textW = FontManager.sfbold.getWidth(text, textSize);
            float textH = FontManager.sfbold.getHeight(textSize);
            int color = selected ? RenderUtils.rgba(255, 255, 255, (int) (255 * l.a()))
                    : RenderUtils.rgba(150, 150, 150, (int) (255 * l.a()));
            FontManager.sfbold.drawDefaultString(g, text,
                    bx + (bw - textW) / 2f,
                    by + (bh - textH) / 2f,
                    textSize, color);
        }
    }

    private void renderModules(GuiGraphicsExtractor g, Layout l, float mouseX, float mouseY) {
        List<Slot> slots = slots(l);
        for (Slot slot : slots) {
            renderModuleRow(g, l, slot, mouseX, mouseY);
            if (slot.module() == expanded) {
                renderSettings(g, l, slot, mouseX, mouseY);
            }
        }
    }

    private void renderModuleRow(GuiGraphicsExtractor g, Layout l, Slot slot, float mouseX, float mouseY) {
        float a = l.a();
        float rX = l.listX();
        float rY = slot.y();
        float rW = l.listW();
        float rH = slot.rowHeight();
        boolean enabled = slot.module().isState();
        boolean hovered = MouseUtility.isHovered(mouseX, mouseY, rX, rY, rW, rH);

        int bg = hovered ? ROW_HOVER : (enabled ? ROW_ENABLED : ROW_BG);
        RenderUtils.drawRoundedRectangle(g, rX, rY, rW, 4 * a, rH, bg);
        if (enabled) {
            RenderUtils.drawRoundedBorder(g, rX, rY, rW, rH, 4 * a, 1 * a, ACCENT);
        }

        // name
        String name = slot.module().getName();
        float textSize = 11 * a;
        float textH = FontManager.sfbold.getHeight(textSize);
        FontManager.sfbold.drawDefaultString(g, name, rX + 8 * a,
                rY + (rH - textH) / 2f, textSize,
                RenderUtils.rgba(255, 255, 255, (int) (255 * a)));

        // expand button
        float ex = expandX(l, rX, rW);
        float ey = expandY(l, rY, rH);
        float es = EXPAND_BUTTON_SIZE * a;
        boolean expandedHover = MouseUtility.isHovered(mouseX, mouseY, ex, ey, es, es);
        RenderUtils.drawRoundedRectangle(g, ex, ey, es, 3 * a, es, expandedHover ? ROW_HOVER : RenderUtils.rgb(18, 18, 18));
        String expandText = slot.module() == expanded ? "-" : "+";
        float expandTextSize = 10 * a;
        float expandTextW = FontManager.sfbold.getWidth(expandText, expandTextSize);
        FontManager.sfbold.drawDefaultString(g, expandText,
                ex + (es - expandTextW) / 2f,
                ey + (es - FontManager.sfbold.getHeight(expandTextSize)) / 2f,
                expandTextSize, RenderUtils.rgba(180, 180, 180, (int) (255 * a)));

        // toggle pill
        float tx = toggleX(l, rX, rW);
        float ty = toggleY(l, rY, rH);
        float tw = TOGGLE_WIDTH * a;
        float th = TOGGLE_HEIGHT * a;
        RenderUtils.drawRoundedRectangle(g, tx, ty, tw, th / 2f, th, enabled ? ACCENT : TRACK);
        float dot = 6 * a;
        float dx = enabled ? tx + tw - 2 * a - dot : tx + 2 * a;
        RenderUtils.drawRoundedRectangle(g, dx, ty + (th - dot) / 2f, dot, dot / 2f, dot, WHITE);
    }

    private void renderSettings(GuiGraphicsExtractor g, Layout l, Slot slot, float mouseX, float mouseY) {
        float a = l.a();
        float rX = l.listX();
        float rW = l.listW();
        float baseY = slot.y() + slot.rowHeight() + ROW_GAP * a;
        List<Setting> settings = slot.module().getSettings();

        for (int i = 0; i < settings.size(); i++) {
            Setting setting = settings.get(i);
            float sY = baseY + i * (SETTING_ROW_HEIGHT + SETTING_GAP) * a;
            float sH = SETTING_ROW_HEIGHT * a;

            if (setting instanceof BooleanSetting bool) {
                renderBooleanSetting(g, l, rX, rW, sY, sH, bool);
            } else if (setting instanceof SliderSetting slider) {
                renderSliderSetting(g, l, rX, rW, sY, sH, slider);
            } else if (setting instanceof ModeSetting mode) {
                renderModeSetting(g, l, rX, rW, sY, sH, mode);
            }
        }
    }

    private void renderBooleanSetting(GuiGraphicsExtractor g, Layout l, float rX, float rW, float sY, float sH, BooleanSetting setting) {
        float a = l.a();
        RenderUtils.drawRoundedRectangle(g, rX, sY, rW, 3 * a, sH, SETTING_BG);

        String name = setting.getName();
        float textSize = 9.5f * a;
        FontManager.sfmedium.drawDefaultString(g, name, rX + 12 * a,
                sY + (sH - FontManager.sfmedium.getHeight(textSize)) / 2f, textSize,
                RenderUtils.rgba(235, 235, 235, (int) (255 * a)));

        float pw = 22 * a;
        float ph = 10 * a;
        float px = rX + rW - 8 * a - pw;
        float py = sY + (sH - ph) / 2f;
        RenderUtils.drawRoundedRectangle(g, px, py, pw, ph / 2f, ph, setting.getValue() ? ACCENT : TRACK);
        float dot = 6 * a;
        float dx = setting.getValue() ? px + pw - 2 * a - dot : px + 2 * a;
        RenderUtils.drawRoundedRectangle(g, dx, py + (ph - dot) / 2f, dot, dot / 2f, dot, WHITE);
    }

    private void renderSliderSetting(GuiGraphicsExtractor g, Layout l, float rX, float rW, float sY, float sH, SliderSetting setting) {
        float a = l.a();
        RenderUtils.drawRoundedRectangle(g, rX, sY, rW, 3 * a, sH, SETTING_BG);

        String name = setting.getName();
        String value = String.format("%.1f", setting.getValue());
        float textSize = 9.5f * a;
        FontManager.sfmedium.drawDefaultString(g, name, rX + 12 * a, sY + 1.5f * a, textSize,
                RenderUtils.rgba(235, 235, 235, (int) (255 * a)));
        float valueW = FontManager.sfmedium.getWidth(value, textSize);
        FontManager.sfmedium.drawDefaultString(g, value, rX + rW - 12 * a - valueW, sY + 1.5f * a, textSize,
                RenderUtils.rgba(157, 120, 255, (int) (255 * a)));

        // bar
        float bx = rX + 12 * a;
        float bW = Math.max(0, rW - 24 * a);
        float by = sY + sH - 4.5f * a;
        float bH = 2.5f * a;
        RenderUtils.drawRoundedRectangle(g, bx, by, bW, bH / 2f, bH, TRACK);
        RenderUtils.drawRoundedRectangle(g, bx, by, bW * setting.getProgress(), bH / 2f, bH, ACCENT);

        // small knob
        float knob = 5 * a;
        float kx = bx + bW * setting.getProgress() - knob / 2f;
        RenderUtils.drawRoundedRectangle(g, kx, by + (bH - knob) / 2f, knob, knob / 2f, knob,
                RenderUtils.rgba(255, 255, 255, (int) (255 * a)));
    }

    private void renderModeSetting(GuiGraphicsExtractor g, Layout l, float rX, float rW, float sY, float sH, ModeSetting setting) {
        float a = l.a();
        RenderUtils.drawRoundedRectangle(g, rX, sY, rW, 3 * a, sH, SETTING_BG);

        String name = setting.getName();
        String current = setting.getValue();
        float textSize = 9.5f * a;
        FontManager.sfmedium.drawDefaultString(g, name, rX + 12 * a,
                sY + (sH - FontManager.sfmedium.getHeight(textSize)) / 2f, textSize,
                RenderUtils.rgba(235, 235, 235, (int) (255 * a)));

        // chip with the current mode
        float cw = FontManager.sfmedium.getWidth(current, textSize) + 12 * a;
        float ch = 12 * a;
        float cx = rX + rW - 8 * a - cw;
        float cy = sY + (sH - ch) / 2f;
        RenderUtils.drawRoundedRectangle(g, cx, cy, cw, 6 * a, ch, ACCENT_SOFT);
        FontManager.sfmedium.drawDefaultString(g, current, cx + 6 * a,
                cy + (ch - FontManager.sfmedium.getHeight(textSize)) / 2f, textSize,
                RenderUtils.rgba(255, 255, 255, (int) (255 * a)));
    }

    // ============================================================
    //  Interaction
    // ============================================================

    private void handleSidebarClick(Layout l, float mx, float my) {
        Type[] types = Type.values();
        for (int i = 0; i < types.length; i++) {
            if (MouseUtility.isHovered(mx, my,
                    categoryButtonX(l), categoryButtonY(l, i), categoryButtonW(l), categoryButtonH(l))) {
                if (selectedType != types[i]) {
                    selectedType = types[i];
                    scrollOffset = 0;
                    expanded = null;
                }
                return;
            }
        }
    }

    private void handleModuleClick(Layout l, float mx, float my) {
        List<Slot> slots = slots(l);
        for (Slot slot : slots) {
            float rX = l.listX();
            float rW = l.listW();
            float rowH = slot.rowHeight();
            Module module = slot.module();

            // expand button
            float es = EXPAND_BUTTON_SIZE * l.a();
            if (MouseUtility.isHovered(mx, my, expandX(l, rX, rW), expandY(l, slot.y(), rowH), es, es)) {
                expanded = (expanded == module) ? null : module;
                return;
            }

            // whole row toggles the module
            if (MouseUtility.isHovered(mx, my, rX, slot.y(), rW, rowH)) {
                module.touch();
                return;
            }

            // settings rows
            if (module == expanded) {
                float baseY = slot.y() + rowH + ROW_GAP * l.a();
                List<Setting> settings = module.getSettings();
                for (int i = 0; i < settings.size(); i++) {
                    float sY = baseY + i * (SETTING_ROW_HEIGHT + SETTING_GAP) * l.a();
                    float sH = SETTING_ROW_HEIGHT * l.a();
                    if (handleSettingClick(l, settings.get(i), rX, rW, sY, sH, mx, my)) {
                        return;
                    }
                }
            }
        }
    }

    private boolean handleSettingClick(Layout l, Setting setting, float rX, float rW, float sY, float sH, float mx, float my) {
        if (setting instanceof BooleanSetting bool) {
            if (MouseUtility.isHovered(mx, my, rX, sY, rW, sH)) {
                bool.toggle();
                return true;
            }
        } else if (setting instanceof SliderSetting slider) {
            float bx = rX + 12 * l.a();
            float bW = Math.max(0, rW - 24 * l.a());
            float by = sY + sH - 4.5f * l.a();
            float bH = 2.5f * l.a();
            if (bW > 0 && MouseUtility.isHovered(mx, my, bx, by - 4 * l.a(), bW, bH + 6 * l.a())) {
                slider.setProgress((mx - bx) / bW);
                draggingSlider = slider;
                return true;
            }
        } else if (setting instanceof ModeSetting mode) {
            if (MouseUtility.isHovered(mx, my, rX, sY, rW, sH)) {
                mode.cycle();
                return true;
            }
        }
        return false;
    }

    private void updateSliderDrag(Layout l, float mouseX) {
        if (draggingSlider == null) return;
        float a = l.a();
        float bx = l.listX() + 12 * a;
        float bW = Math.max(0, l.listW() - 24 * a);
        if (bW <= 0) return;
        draggingSlider.setProgress((mouseX - bx) / bW);
    }
}